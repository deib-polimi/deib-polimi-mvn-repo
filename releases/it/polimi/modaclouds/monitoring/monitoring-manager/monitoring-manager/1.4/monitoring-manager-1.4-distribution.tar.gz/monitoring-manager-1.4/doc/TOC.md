Documentation table of contents

# MODAClouds Monitoring Manager API documentation

* [User Manual](user-manual.md)
* [Developer Manual](dev-manual.md)
* [API Reference](api.md)
* [Required Interfaces](required-if.md)