[Documentation table of contents](TOC.md) / Developer Manual

#Developer Manual

## Integration Test

In order to run integration tests [Vagrant](http://www.vagrantup.com) is required for creating a virtualized environement. Once installed just run `mvn verify`.